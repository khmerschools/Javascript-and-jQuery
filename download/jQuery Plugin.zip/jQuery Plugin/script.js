(function($){

	$.fn.myfun = function(opts){

		var settings = $.extend({
			bColor:'#dddddd',
			text:'#000000'
		},opts);

		this.css({'background':settings.bColor,'color':settings.text});
	}

}(jQuery));